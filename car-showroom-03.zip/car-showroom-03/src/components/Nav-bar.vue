<template>
  <div class="title">
    <h1>Car Gallery</h1>
    <hr />
  </div>
</template>

<script>
export default {
  name: "Nav-bar",
};
</script>

<style>
.title {
  text-align: center;
}

hr {
  width: 8%;
  border: 5px solid brown;
  border-radius: 5px;
}

.title h1 {
  color: black;
  font-size: 40px;
  text-shadow: 0 0 3px gray;
}
</style>
